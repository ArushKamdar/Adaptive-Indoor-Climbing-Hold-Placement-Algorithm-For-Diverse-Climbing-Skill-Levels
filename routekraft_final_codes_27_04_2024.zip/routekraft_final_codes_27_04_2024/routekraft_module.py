import cv2
import numpy as np
from random import randint
from scipy.spatial.distance import euclidean

def wall_width(width_input):
    # Minimum wall width = 200 cms
    while width_input < 200: 
        ret_str = "Kindly input a value equal to 200 or more in cms (200 cms = 80 inches = 6.66 Feet) for Width of the Wall"
        return ret_str
    if width_input < 500:
        scale_factor = 1
    if width_input >= 500:
        scale_factor = 2
    return width_input, scale_factor

def wall_height(height_input):
    # Minimum wall height = 200 cms
    while height_input < 200: 
        ret_str = "Kindly input a value equal to 200 or more in cms (200 cms = 80 inches = 6.66 Feet) for Height of the Wall"
        return ret_str
    if height_input < 500:
        scale_factor = 1
    if height_input >= 500:
        scale_factor = 2
    return height_input, scale_factor

def create_wall_img(width_input, height_input):
    if width_input < 500 or height_input < 500:
        scale_factor = 1
    if width_input >= 500 or height_input >= 500:
        scale_factor = 2
    # Creating the wall image
    wall_img = np.full((int(width_input // scale_factor), int(height_input // scale_factor), 3), fill_value=255, dtype=np.uint8)
    return wall_img, scale_factor

def climber_height(climber_height):
    # 2 feet = 60.96 centimeters (minimum height)
    # 4 feet = 109.2 centimeters
    # 10 feet = 304.8 centimeters (maximum height)
    while climber_height < 60 or climber_height > 305:
            ret_str = "Enter a value greater than 60 cms and less than 305 cms for your height : "
            return ret_str
    return climber_height

def hold_img(scale_factor):
    # Images of Holds
    # width & height of the hold image
    crimp_width, crimp_height = 16//scale_factor, 16//scale_factor
    crimp = cv2.resize(cv2.imread(".\\rockclimbingholdsimages\\crimp.png"), (crimp_width, crimp_height))

    pinch_width, pinch_height = 10//scale_factor, 26//scale_factor
    pinch = cv2.resize(cv2.imread(".\\rockclimbingholdsimages\\pinch.png"), (pinch_width, pinch_height))

    edge_width, edge_height = 20//scale_factor, 16//scale_factor
    edge = cv2.resize(cv2.imread(".\\rockclimbingholdsimages\\edge.png"), (edge_width, edge_height))

    pocket_width, pocket_height = 26//scale_factor, 26//scale_factor
    pocket = cv2.resize(cv2.imread(".\\rockclimbingholdsimages\\pocket.png"), (pocket_width, pocket_height))

    jug_width, jug_height = 30//scale_factor, 30//scale_factor
    jug = cv2.resize(cv2.imread(".\\rockclimbingholdsimages\\jug.png"), (jug_width, jug_height))

    sloper_width, sloper_height = 40//scale_factor, 40//scale_factor
    sloper = cv2.resize(cv2.imread(".\\rockclimbingholdsimages\\sloper.png"), (sloper_width, sloper_height))

    holds_list = [[crimp, [crimp_width, crimp_height], "Crimp"], [pinch, [pinch_width, pinch_height], "Pinch"], [edge, [edge_width, edge_height], "Edge"], [pocket, [pocket_width, pocket_height], "Pocket"], [jug, [jug_width, jug_height], "Jug"], [sloper, [sloper_width, sloper_height], "Sloper"]]

    return holds_list

def foothold_img(scale_factor):
    foothold_width, foothold_height = 16//scale_factor,16//scale_factor
    foothold = cv2.resize(cv2.imread(".\\rockclimbingholdsimages\\foothold.png"), (foothold_width, foothold_height))
    return foothold, foothold_width, foothold_height

def custom_holds_list_gen(experience_level, climber_height, holds_list, scale_factor):
    # Difficulty Level based on Climbing Experience
    x_range = 0
    y_range_s = 0
    y_range_e = 0

    height_factor = climber_height // 20

    if experience_level.lower() == "beginner":
        x_range = 30 + height_factor
        y_range_s = 30 + height_factor
        y_range_e = 20 + height_factor

        del holds_list[0]
        del holds_list[0]
        del holds_list[1]
        del holds_list[2]

    elif experience_level.lower() == "intermediate":
        x_range =  (50 + height_factor)//scale_factor
        y_range_s = (50 + height_factor)//scale_factor
        y_range_e = (30 + height_factor)//scale_factor

        del holds_list[4]

    elif experience_level.lower() == "expert":
        x_range = 70 + height_factor
        y_range_s = 70 + height_factor
        y_range_e = 30 + height_factor
        
    return holds_list, x_range, y_range_s, y_range_e

def first_two_footholds(first_hold_coord_list, height_input, foothold_width, foothold_height, wall_img, foothold):
    # for placing footholds

    first_foothold_1_x = first_hold_coord_list[0] - 30
    first_foothold_1_y = height_input - 20
    first_foothold_2_x = first_hold_coord_list[0] + 30
    first_foothold_2_y = height_input - 20
    value_for_foothold_x = foothold_width//2
    value_for_foothold_y = foothold_height//2
    foothold_img_tl_x = first_foothold_1_x - value_for_foothold_x
    foothold_img_tl_y = first_foothold_1_y - value_for_foothold_y
    foothold_img_br_x = first_foothold_1_x + value_for_foothold_x
    foothold_img_br_y = first_foothold_1_y + value_for_foothold_y
    
    wall_img[foothold_img_tl_y : foothold_img_br_y, foothold_img_tl_x : foothold_img_br_x] = foothold

    foothold_img_tl_x = first_foothold_2_x - value_for_foothold_x
    foothold_img_tl_y = first_foothold_2_y - value_for_foothold_y
    foothold_img_br_x = first_foothold_2_x + value_for_foothold_x
    foothold_img_br_y = first_foothold_2_y + value_for_foothold_y
    # slice_width = foothold_img_tl_x - foothold_img_br_x
    # slice_height = foothold_img_tl_y - foothold_img_br_y
    # foothold_img_resized = cv2.resize(foothold, (slice_width, slice_height))
    wall_img[foothold_img_tl_y : foothold_img_br_y, foothold_img_tl_x : foothold_img_br_x] = foothold
    first_foothold_1_details = f"First Foothold 1 : ({first_foothold_1_x}, 20)"
    first_foothold_1 = f"({first_foothold_1_x}, 20)"
    cv2.putText(wall_img, first_foothold_1, (first_foothold_1_x - 80, first_foothold_1_y), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 0), 1, cv2.LINE_AA)
    first_foothold_2_details = f"First Foothold 2 : ({first_foothold_2_x}, 20)"
    first_foothold_2 = f"({first_foothold_2_x}, 20)"
    cv2.putText(wall_img, first_foothold_2, (first_foothold_2_x + 20, first_foothold_2_y), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 0), 1, cv2.LINE_AA)

    return wall_img, first_foothold_1_details, first_foothold_2_details

def second_foothold(third_hold_coord_list, height_input, foothold_width, foothold_height, wall_img, foothold):
    second_foothold_1_x = third_hold_coord_list[0] - 30
    second_foothold_1_y = height_input - 80
    second_foothold_2_x = third_hold_coord_list[0] + 30
    second_foothold_2_y = height_input - 80
    value_for_foothold_x = foothold_width//2
    value_for_foothold_y = foothold_height//2
    foothold_img_tl_x = second_foothold_1_x - value_for_foothold_x
    foothold_img_tl_y = second_foothold_1_y - value_for_foothold_y
    foothold_img_br_x = second_foothold_1_x + value_for_foothold_x
    foothold_img_br_y = second_foothold_1_y + value_for_foothold_y
    wall_img[foothold_img_tl_y : foothold_img_br_y, foothold_img_tl_x : foothold_img_br_x] = foothold

    foothold_img_tl_x = second_foothold_2_x - value_for_foothold_x
    foothold_img_tl_y = second_foothold_2_y - value_for_foothold_y
    foothold_img_br_x = second_foothold_2_x + value_for_foothold_x
    foothold_img_br_y = second_foothold_2_y + value_for_foothold_y
    wall_img[foothold_img_tl_y : foothold_img_br_y, foothold_img_tl_x : foothold_img_br_x] = foothold

    second_foothold_1_details = f"Second Foothold 1 : ({second_foothold_1_x}, {height_input - second_foothold_1_y})"
    second_foothold_1 = f"({second_foothold_1_x}, {height_input - second_foothold_1_y})"
    cv2.putText(wall_img, second_foothold_1, (second_foothold_1_x - 80, second_foothold_1_y), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 0), 1, cv2.LINE_AA)
    second_foothold_2_details = f"Second Foothold 2 : ({second_foothold_2_x}, {height_input - second_foothold_2_y})"
    second_foothold_2 = f"({second_foothold_2_x}, {height_input - second_foothold_2_y})"
    cv2.putText(wall_img, second_foothold_2, (second_foothold_2_x + 20, second_foothold_2_y), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 0), 1, cv2.LINE_AA)
    return wall_img, second_foothold_1_details, second_foothold_2_details

def third_foothold(fifth_hold_coord_list, first_hold_coord_list, height_input, foothold_width, foothold_height, wall_img, foothold):
    distance_for_foothold = fifth_hold_coord_list[0] - first_hold_coord_list[0]    
    third_foothold_x = fifth_hold_coord_list[0] + distance_for_foothold
    third_foothold_y = first_hold_coord_list[1]

    value_for_foothold_x = foothold_width//2
    value_for_foothold_y = foothold_height//2
    foothold_img_tl_x = third_foothold_x - value_for_foothold_x
    foothold_img_tl_y = third_foothold_y - value_for_foothold_y
    foothold_img_br_x = third_foothold_x + value_for_foothold_x
    foothold_img_br_y = third_foothold_y + value_for_foothold_y
    # if distance_for_foothold > 20 or distance_for_foothold < -20:
    wall_img[foothold_img_tl_y : foothold_img_br_y, foothold_img_tl_x : foothold_img_br_x] = foothold
    third_foothold_details = f"Third Foothold : ({third_foothold_x}, {height_input - third_foothold_y})"
    third_foothold = f"({third_foothold_x}, {height_input - third_foothold_y})"
    cv2.putText(wall_img, third_foothold, (third_foothold_x - 20, third_foothold_y + 30), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 0), 1, cv2.LINE_AA)

    return wall_img, third_foothold_details

def fourth_foothold(third_hold_coord_list, fourth_hold_coord_list, eighth_hold_coord_list, height_input, foothold_width, foothold_height, wall_img, foothold):
    distance_for_foothold4_1 = eighth_hold_coord_list[0] - fourth_hold_coord_list[0]   
    distance_for_foothold4_2 = eighth_hold_coord_list[0] - third_hold_coord_list[0]
    fourth1_foothold_x = eighth_hold_coord_list[0] + distance_for_foothold4_1
    fourth1_foothold_y = fourth_hold_coord_list[1]

    value_for_foothold_x = foothold_width//2
    value_for_foothold_y = foothold_height//2
    foothold_img_tl_x = fourth1_foothold_x - value_for_foothold_x
    foothold_img_tl_y = fourth1_foothold_y - value_for_foothold_y
    foothold_img_br_x = fourth1_foothold_x + value_for_foothold_x
    foothold_img_br_y = fourth1_foothold_y + value_for_foothold_y

    fourth2_foothold_x = eighth_hold_coord_list[0] + distance_for_foothold4_2
    fourth2_foothold_y = fourth_hold_coord_list[1]

    value_for_foothold_x = foothold_width//2
    value_for_foothold_y = foothold_height//2
    foothold_img_tl_x2 = fourth2_foothold_x - value_for_foothold_x
    foothold_img_tl_y2 = fourth2_foothold_y - value_for_foothold_y
    foothold_img_br_x2 = fourth2_foothold_x + value_for_foothold_x
    foothold_img_br_y2 = fourth2_foothold_y + value_for_foothold_y

    # if distance_for_foothold4_1 > 20 or distance_for_foothold4_1 < -20:
    wall_img[foothold_img_tl_y : foothold_img_br_y, foothold_img_tl_x : foothold_img_br_x] = foothold
    fourth1_foothold_details = f"Fourth1 Foothold : ({fourth1_foothold_x}, {height_input - fourth1_foothold_y})"
    cv2.putText(wall_img, fourth1_foothold_details, (fourth1_foothold_x - 20, fourth1_foothold_y + 30), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 0), 1, cv2.LINE_AA)
    # elif distance_for_foothold4_2 > 20 or distance_for_foothold4_2 < -20:
    wall_img[foothold_img_tl_y2 : foothold_img_br_y2, foothold_img_tl_x2 : foothold_img_br_x2] = foothold
    fourth2_foothold_details = f"Fourth2 Foothold : ({fourth2_foothold_x}, {height_input - fourth2_foothold_y})"
    cv2.putText(wall_img, fourth2_foothold_details, (fourth2_foothold_x - 20, fourth2_foothold_y + 30), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 0), 1, cv2.LINE_AA)

    return wall_img, fourth1_foothold_details, fourth2_foothold_details

def first_hold(wall_img, wall_width, wall_height, climber_height, holds_list, scale_factor):    

    # Position of First hold

    first_hold_x = (wall_width // 2)

    first_hold_y = (randint(climber_height // 2, climber_height))

    first_hold_y = wall_height - first_hold_y 

    first_hold = [first_hold_x, first_hold_y]

    first_hold_y_show = wall_height - first_hold_y

    # Placing first hold image on the wall image

    # Finding a random hold from the holds_list for the first hold

    hold_ind = randint(0, len(holds_list) - 1)

    first_hold_list = holds_list[hold_ind]
    first_hold_image = holds_list[hold_ind][0]
    first_hold_name = holds_list[hold_ind][2]

    first_hold_width = first_hold_list[1][0]
    first_hold_height = first_hold_list[1][1]

    value_for_x = (first_hold_width // 2) 
    value_for_y = (first_hold_height // 2)
        
    # top left corner x & y coordinates for the image of first hold

    first_hold_img_tl_x = (first_hold_x - value_for_x)//scale_factor
    first_hold_img_tl_y = (first_hold_y - value_for_y)//scale_factor

    # bottom right corner x & y coordinates for the image of first hold

    first_hold_img_br_x = (first_hold_x + value_for_x)//scale_factor
    first_hold_img_br_y = (first_hold_y + value_for_y)//scale_factor

    wall_img[first_hold_img_tl_y : first_hold_img_br_y, first_hold_img_tl_x : first_hold_img_br_x] = first_hold_image

    first_hold_details = f"{first_hold_name} : ({first_hold_x}, {first_hold_y_show})"

    first_hold_coord_list = [first_hold_x, first_hold_y_show]

    cv2.putText(wall_img, first_hold_details, (first_hold[0] + 20, first_hold[1]), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 0), 1, cv2.LINE_AA)

    return wall_img, first_hold_details, first_hold_coord_list

def second_hold(wall_img, wall_height, holds_list, first_hold_coord_list, x_range, y_range_s, y_range_e):
    # Position of Second hold

    second_hold_x = randint(first_hold_coord_list[0] - x_range, first_hold_coord_list[0] + x_range)

    second_hold_y = randint(first_hold_coord_list[1] - y_range_s, first_hold_coord_list[1] - y_range_e)

    second_hold = [second_hold_x, second_hold_y]

    second_hold_y_show = wall_height - second_hold_y

    # Placing second hold image on the wall image

    # Finding a random hold from the holds_list for the second hold

    hold_ind = randint(0, len(holds_list) - 1)

    second_hold_list = holds_list[hold_ind]
    second_hold_image = holds_list[hold_ind][0]
    second_hold_name = holds_list[hold_ind][2]

    second_hold_width = second_hold_list[1][0]
    second_hold_height = second_hold_list[1][1]

    value_for_x = second_hold_width // 2
    value_for_y = second_hold_height // 2
        
    # top left corner x & y coordinates for the image of second hold

    second_hold_img_tl_x = second_hold_x - value_for_x
    second_hold_img_tl_y = second_hold_y - value_for_y

    # bottom right corner x & y coordinates for the image of second hold

    second_hold_img_br_x = second_hold_x + value_for_x
    second_hold_img_br_y = second_hold_y + value_for_y

    wall_img[second_hold_img_tl_y : second_hold_img_br_y, second_hold_img_tl_x : second_hold_img_br_x] = second_hold_image

    second_hold_details = f"{second_hold_name} : ({second_hold_x}, {second_hold_y_show})"

    second_hold_coord_list = [second_hold_x, second_hold_y_show]

    cv2.putText(wall_img, second_hold_details, (second_hold[0] + 20, second_hold[1]), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 0), 1, cv2.LINE_AA)

    return wall_img, second_hold_details, second_hold_coord_list

def third_hold(wall_img, wall_height, holds_list, second_hold_coord_list, x_range, y_range_s, y_range_e):
    # Position of Third hold

    third_hold_x = randint(second_hold_coord_list[0] - x_range, second_hold_coord_list[0] + x_range)

    third_hold_y = randint(second_hold_coord_list[1] - y_range_s, second_hold_coord_list[1] - y_range_e)

    third_hold = [third_hold_x, third_hold_y]

    third_hold_y_show = wall_height - third_hold_y

    # Placing third hold image on the wall image

    # Finding a random hold from the holds_list for the third hold

    hold_ind = randint(0, len(holds_list) - 1)

    third_hold_list = holds_list[hold_ind]
    third_hold_image = holds_list[hold_ind][0]
    third_hold_name = holds_list[hold_ind][2]

    third_hold_width = third_hold_list[1][0]
    third_hold_height = third_hold_list[1][1]

    value_for_x = third_hold_width // 2
    value_for_y = third_hold_height // 2
        
    # top left corner x & y coordinates for the image of third hold

    third_hold_img_tl_x = third_hold_x - value_for_x
    third_hold_img_tl_y = third_hold_y - value_for_y

    # bottom right corner x & y coordinates for the image of third hold

    third_hold_img_br_x = third_hold_x + value_for_x
    third_hold_img_br_y = third_hold_y + value_for_y

    wall_img[third_hold_img_tl_y : third_hold_img_br_y, third_hold_img_tl_x : third_hold_img_br_x] = third_hold_image

    third_hold_details = f"{third_hold_name} : ({third_hold_x}, {third_hold_y_show})"

    third_hold_coord_list = [third_hold_x, third_hold_y_show]

    cv2.putText(wall_img, third_hold_details, (third_hold[0] + 20, third_hold[1]), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 0), 1, cv2.LINE_AA)

    return wall_img, third_hold_details, third_hold_coord_list

def fourth_hold(wall_img, wall_height, holds_list, third_hold_coord_list, x_range, y_range_s, y_range_e):
    # Position of Fourth hold

    fourth_hold_x = randint(third_hold_coord_list[0] - x_range, third_hold_coord_list[0] + x_range)

    fourth_hold_y = randint(third_hold_coord_list[1] - y_range_s, third_hold_coord_list[1] - y_range_e)

    fourth_hold = [fourth_hold_x, fourth_hold_y]

    fourth_hold_y_show = wall_height - fourth_hold_y

    # Placing fourth hold image on the wall image

    # Finding a random hold from the holds_list for the fourth hold

    hold_ind = randint(0, len(holds_list) - 1)

    fourth_hold_list = holds_list[hold_ind]
    fourth_hold_image = holds_list[hold_ind][0]
    fourth_hold_name = holds_list[hold_ind][2]

    fourth_hold_width = fourth_hold_list[1][0]
    fourth_hold_height = fourth_hold_list[1][1]

    value_for_x = fourth_hold_width // 2
    value_for_y = fourth_hold_height // 2
        
    # top left corner x & y coordinates for the image of fourth hold

    fourth_hold_img_tl_x = fourth_hold_x - value_for_x
    fourth_hold_img_tl_y = fourth_hold_y - value_for_y

    # bottom right corner x & y coordinates for the image of fourth hold

    fourth_hold_img_br_x = fourth_hold_x + value_for_x
    fourth_hold_img_br_y = fourth_hold_y + value_for_y

    # print(f"fourth Hold Image Coords : {fourth_hold_img_tl_x, fourth_hold_img_tl_y}, {fourth_hold_img_br_x, fourth_hold_img_br_y}")

    wall_img[fourth_hold_img_tl_y : fourth_hold_img_br_y, fourth_hold_img_tl_x : fourth_hold_img_br_x] = fourth_hold_image

    fourth_hold_details = f"{fourth_hold_name} : ({fourth_hold_x}, {fourth_hold_y_show})"
    fourth_hold_coord_list = [fourth_hold_x, fourth_hold_y_show]

    cv2.putText(wall_img, fourth_hold_details, (fourth_hold[0] + 20, fourth_hold[1]), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 0), 1, cv2.LINE_AA)

    return wall_img, fourth_hold_details, fourth_hold_coord_list

def fifth_hold(wall_img, wall_height, holds_list, fourth_hold_coord_list, x_range, y_range_s, y_range_e):
    # Position of fifth hold

    fifth_hold_x = randint(fourth_hold_coord_list[0] - x_range, fourth_hold_coord_list[0] + x_range)

    fifth_hold_y = randint(fourth_hold_coord_list[1] - y_range_s, fourth_hold_coord_list[1] - y_range_e)

    fifth_hold = [fifth_hold_x, fifth_hold_y]

    fifth_hold_y_show = wall_height - fifth_hold_y

    # Placing fifth hold image on the wall image

    # Finding a random hold from the holds_list for the fifth hold

    hold_ind = randint(0, len(holds_list) - 1)

    fifth_hold_list = holds_list[hold_ind]
    fifth_hold_image = holds_list[hold_ind][0]
    fifth_hold_name = holds_list[hold_ind][2]

    fifth_hold_width = fifth_hold_list[1][0]
    fifth_hold_height = fifth_hold_list[1][1]

    value_for_x = fifth_hold_width // 2
    value_for_y = fifth_hold_height // 2
        
    # top left corner x & y coordinates for the image of fifth hold

    fifth_hold_img_tl_x = fifth_hold_x - value_for_x
    fifth_hold_img_tl_y = fifth_hold_y - value_for_y

    # bottom right corner x & y coordinates for the image of fifth hold

    fifth_hold_img_br_x = fifth_hold_x + value_for_x
    fifth_hold_img_br_y = fifth_hold_y + value_for_y

    wall_img[fifth_hold_img_tl_y : fifth_hold_img_br_y, fifth_hold_img_tl_x : fifth_hold_img_br_x] = fifth_hold_image

    fifth_hold_details = f"{fifth_hold_name} : ({fifth_hold_x}, {fifth_hold_y_show})"
    fifth_hold_coord_list = [fifth_hold_x, fifth_hold_y_show]

    cv2.putText(wall_img, fifth_hold_details, (fifth_hold[0] + 20, fifth_hold[1]), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 0), 1, cv2.LINE_AA)

    return wall_img, fifth_hold_details, fifth_hold_coord_list

def sixth_hold(wall_img, wall_height, holds_list, fifth_hold_coord_list, x_range, y_range_s, y_range_e):
    # Position of sixth hold

    sixth_hold_x = randint(fifth_hold_coord_list[0] - x_range, fifth_hold_coord_list[0] + x_range)

    sixth_hold_y = randint(fifth_hold_coord_list[1] - y_range_s, fifth_hold_coord_list[1] - y_range_e)

    sixth_hold = [sixth_hold_x, sixth_hold_y]

    sixth_hold_y_show = wall_height - sixth_hold_y

    # Placing sixth hold image on the wall image

    # Finding a random hold from the holds_list for the sixth hold

    hold_ind = randint(0, len(holds_list) - 1)

    sixth_hold_list = holds_list[hold_ind]
    sixth_hold_image = holds_list[hold_ind][0]
    sixth_hold_name = holds_list[hold_ind][2]

    sixth_hold_width = sixth_hold_list[1][0]
    sixth_hold_height = sixth_hold_list[1][1]

    value_for_x = sixth_hold_width // 2
    value_for_y = sixth_hold_height // 2
        
    # top left corner x & y coordinates for the image of sixth hold

    sixth_hold_img_tl_x = sixth_hold_x - value_for_x
    sixth_hold_img_tl_y = sixth_hold_y - value_for_y

    # bottom right corner x & y coordinates for the image of sixth hold

    sixth_hold_img_br_x = sixth_hold_x + value_for_x
    sixth_hold_img_br_y = sixth_hold_y + value_for_y

    wall_img[sixth_hold_img_tl_y : sixth_hold_img_br_y, sixth_hold_img_tl_x : sixth_hold_img_br_x] = sixth_hold_image

    sixth_hold_details = f"{sixth_hold_name} : ({sixth_hold_x}, {sixth_hold_y_show})"
    sixth_hold_coord_list = [sixth_hold_x, sixth_hold_y_show]

    cv2.putText(wall_img, sixth_hold_details, (sixth_hold[0] + 20, sixth_hold[1]), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 0), 1, cv2.LINE_AA)

    return wall_img, sixth_hold_details, sixth_hold_coord_list

def seventh_hold(wall_img, wall_height, holds_list, sixth_hold_coord_list, x_range, y_range_s, y_range_e):
    # Position of seventh hold

    seventh_hold_x = randint(sixth_hold_coord_list[0] - x_range, sixth_hold_coord_list[0] + x_range)

    seventh_hold_y = randint(sixth_hold_coord_list[1] - y_range_s, sixth_hold_coord_list[1] - y_range_e)

    seventh_hold = [seventh_hold_x, seventh_hold_y]

    seventh_hold_y_show = wall_height - seventh_hold_y

    # Placing seventh hold image on the wall image

    # Finding a random hold from the holds_list for the seventh hold

    hold_ind = randint(0, len(holds_list) - 1)

    seventh_hold_list = holds_list[hold_ind]
    seventh_hold_image = holds_list[hold_ind][0]
    seventh_hold_name = holds_list[hold_ind][2]

    seventh_hold_width = seventh_hold_list[1][0]
    seventh_hold_height = seventh_hold_list[1][1]

    value_for_x = seventh_hold_width // 2
    value_for_y = seventh_hold_height // 2
        
    # top left corner x & y coordinates for the image of seventh hold

    seventh_hold_img_tl_x = seventh_hold_x - value_for_x
    seventh_hold_img_tl_y = seventh_hold_y - value_for_y

    # bottom right corner x & y coordinates for the image of seventh hold

    seventh_hold_img_br_x = seventh_hold_x + value_for_x
    seventh_hold_img_br_y = seventh_hold_y + value_for_y

    wall_img[seventh_hold_img_tl_y : seventh_hold_img_br_y, seventh_hold_img_tl_x : seventh_hold_img_br_x] = seventh_hold_image

    seventh_hold_details = f"{seventh_hold_name} : ({seventh_hold_x}, {seventh_hold_y_show})"
    seventh_hold_coord_list = [seventh_hold_x, seventh_hold_y_show]

    cv2.putText(wall_img, seventh_hold_details, (seventh_hold[0] + 20, seventh_hold[1]), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 0), 1, cv2.LINE_AA)

    return wall_img, seventh_hold_details, seventh_hold_coord_list

def eighth_hold(wall_img, wall_height, holds_list, seventh_hold_coord_list, x_range, y_range_s, y_range_e):
    # Position of eighth hold

    eighth_hold_x = randint(seventh_hold_coord_list[0] - x_range, seventh_hold_coord_list[0] + x_range)

    eighth_hold_y = randint(seventh_hold_coord_list[1] - y_range_s, seventh_hold_coord_list[1] - y_range_e)

    eighth_hold = [eighth_hold_x, eighth_hold_y]

    eighth_hold_y_show = wall_height - eighth_hold_y

    # Placing eighth hold image on the wall image

    # Finding a random hold from the holds_list for the eighth hold

    hold_ind = randint(0, len(holds_list) - 1)

    eighth_hold_list = holds_list[hold_ind]
    eighth_hold_image = holds_list[hold_ind][0]
    eighth_hold_name = holds_list[hold_ind][2]

    eighth_hold_width = eighth_hold_list[1][0]
    eighth_hold_height = eighth_hold_list[1][1]

    value_for_x = eighth_hold_width // 2
    value_for_y = eighth_hold_height // 2
        
    # top left corner x & y coordinates for the image of eighth hold

    eighth_hold_img_tl_x = eighth_hold_x - value_for_x
    eighth_hold_img_tl_y = eighth_hold_y - value_for_y

    # bottom right corner x & y coordinates for the image of eighth hold

    eighth_hold_img_br_x = eighth_hold_x + value_for_x
    eighth_hold_img_br_y = eighth_hold_y + value_for_y

    wall_img[eighth_hold_img_tl_y : eighth_hold_img_br_y, eighth_hold_img_tl_x : eighth_hold_img_br_x] = eighth_hold_image

    eighth_hold_details = f"{eighth_hold_name} : ({eighth_hold_x}, {eighth_hold_y_show})"
    eighth_hold_coord_list = [eighth_hold_x, eighth_hold_y_show]

    cv2.putText(wall_img, eighth_hold_details, (eighth_hold[0] + 20, eighth_hold[1]), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 0), 1, cv2.LINE_AA)

    return wall_img, eighth_hold_details, eighth_hold_coord_list

def dist_bet_holds(first_hold_coord_list, second_hold_coord_list, third_hold_coord_list, fourth_hold_coord_list, fifth_hold_coord_list, sixth_hold_coord_list, seventh_hold_coord_list, eighth_hold_coord_list):
    distance_between_first_and_third = euclidean(np.array(first_hold_coord_list), np.array(third_hold_coord_list))
    distance_between_second_and_third = euclidean(np.array(second_hold_coord_list), np.array(third_hold_coord_list))

    distance_between_third_and_fourth = euclidean(np.array(third_hold_coord_list), np.array(fourth_hold_coord_list))
    distance_between_second_and_fourth = euclidean(np.array(second_hold_coord_list), np.array(fourth_hold_coord_list))
    distance_between_first_and_fourth = euclidean(np.array(first_hold_coord_list), np.array(fourth_hold_coord_list))

    distance_between_fourth_and_fifth = euclidean(np.array(fourth_hold_coord_list), np.array(fifth_hold_coord_list))
    distance_between_third_and_fifth = euclidean(np.array(third_hold_coord_list), np.array(fifth_hold_coord_list))
    distance_between_second_and_fifth = euclidean(np.array(second_hold_coord_list), np.array(fifth_hold_coord_list))
    distance_between_first_and_fifth = euclidean(np.array(first_hold_coord_list), np.array(fifth_hold_coord_list))

    distance_between_fifth_and_sixth = euclidean(np.array(fifth_hold_coord_list), np.array(sixth_hold_coord_list))
    distance_between_fourth_and_sixth = euclidean(np.array(fourth_hold_coord_list), np.array(sixth_hold_coord_list))
    distance_between_third_and_sixth = euclidean(np.array(third_hold_coord_list), np.array(sixth_hold_coord_list))
    distance_between_second_and_sixth = euclidean(np.array(second_hold_coord_list), np.array(sixth_hold_coord_list))
    distance_between_first_and_sixth = euclidean(np.array(first_hold_coord_list), np.array(sixth_hold_coord_list))

    distance_between_sixth_and_seventh = euclidean(np.array(sixth_hold_coord_list), np.array(seventh_hold_coord_list))
    distance_between_fifth_and_seventh = euclidean(np.array(fifth_hold_coord_list), np.array(seventh_hold_coord_list))
    distance_between_fourth_and_seventh = euclidean(np.array(fourth_hold_coord_list), np.array(seventh_hold_coord_list))
    distance_between_third_and_seventh = euclidean(np.array(third_hold_coord_list), np.array(seventh_hold_coord_list))
    distance_between_second_and_seventh = euclidean(np.array(second_hold_coord_list), np.array(seventh_hold_coord_list))
    distance_between_first_and_seventh = euclidean(np.array(first_hold_coord_list), np.array(seventh_hold_coord_list))

    distance_between_seventh_and_eighth = euclidean(np.array(seventh_hold_coord_list), np.array(eighth_hold_coord_list))
    distance_between_sixth_and_eighth = euclidean(np.array(sixth_hold_coord_list), np.array(eighth_hold_coord_list))
    distance_between_fifth_and_eighth = euclidean(np.array(fifth_hold_coord_list), np.array(eighth_hold_coord_list))
    distance_between_fourth_and_eighth = euclidean(np.array(fourth_hold_coord_list), np.array(eighth_hold_coord_list))
    distance_between_third_and_eighth = euclidean(np.array(third_hold_coord_list), np.array(eighth_hold_coord_list))
    distance_between_second_and_eighth = euclidean(np.array(second_hold_coord_list), np.array(eighth_hold_coord_list))
    distance_between_first_and_eighth = euclidean(np.array(first_hold_coord_list), np.array(eighth_hold_coord_list))

    dist_bet_first_and_third = f"The distance between first & third hold is {distance_between_first_and_third}"
    dist_bet_second_and_third = f"The distance between second & third hold is {distance_between_second_and_third}"

    dist_bet_third_and_fourth = f"The distance between third & fourth hold is {distance_between_third_and_fourth}"
    dist_bet_second_and_fourth = f"The distance between second & fourth hold is {distance_between_second_and_fourth}"
    dist_bet_first_and_fourth = f"The distance between first & fourth hold is {distance_between_first_and_fourth}"

    distance_bet_fourth_and_fifth = f"The distance between fourth & fifth hold is {distance_between_fourth_and_fifth}"
    distance_bet_third_and_fifth = f"The distance between third & fifth hold is {distance_between_third_and_fifth}"
    distance_bet_second_and_fifth = f"The distance between second & fifth hold is {distance_between_second_and_fifth}"
    distance_bet_first_and_fifth = f"The distance between first & fifth hold is {distance_between_first_and_fifth}"

    distance_bet_fifth_and_sixth = f"The distance between fifth & sixth hold is {distance_between_fifth_and_sixth}"
    distance_bet_fourth_and_sixth = f"The distance between fourth & sixth hold is {distance_between_fourth_and_sixth}"
    distance_bet_third_and_sixth = f"The distance between third & sixth hold is {distance_between_third_and_sixth}"
    distance_bet_second_and_sixth = f"The distance between second & sixth hold is {distance_between_second_and_sixth}"
    distance_bet_first_and_sixth = f"The distance between first & sixth hold is {distance_between_first_and_sixth}"

    distance_bet_sixth_and_seventh = f"The distance between sixth & seventh hold is {distance_between_sixth_and_seventh}"
    distance_bet_fifth_and_seventh = f"The distance between fifth & seventh hold is {distance_between_fifth_and_seventh}"
    distance_bet_fourth_and_seventh = f"The distance between fourth & seventh hold is {distance_between_fourth_and_seventh}"
    distance_bet_third_and_seventh = f"The distance between third & seventh hold is {distance_between_third_and_seventh}"
    distance_bet_second_and_seventh = f"The distance between second & seventh hold is {distance_between_second_and_seventh}"
    distance_bet_first_and_seventh = f"The distance between first & seventh hold is {distance_between_first_and_seventh}"

    distance_bet_seventh_and_eighth = f"The distance between seventh & eighth hold is {distance_between_seventh_and_eighth}"
    distance_bet_sixth_and_eighth = f"The distance between sixth & eighth hold is {distance_between_sixth_and_eighth}"
    distance_bet_fifth_and_eighth = f"The distance between fifth & eighth hold is {distance_between_fifth_and_eighth}"
    distance_bet_fourth_and_eighth = f"The distance between fourth & eighth hold is {distance_between_fourth_and_eighth}"
    distance_bet_third_and_eighth = f"The distance between third & eighth hold is {distance_between_third_and_eighth}"
    distance_bet_second_and_eighth = f"The distance between second & eighth hold is {distance_between_second_and_eighth}"
    distance_bet_first_and_eighth = f"The distance between first & eighth hold is {distance_between_first_and_eighth}"

    return dist_bet_first_and_third, dist_bet_second_and_third, dist_bet_third_and_fourth, dist_bet_second_and_fourth, dist_bet_first_and_fourth, distance_bet_fourth_and_fifth, distance_bet_third_and_fifth, distance_bet_second_and_fifth, distance_bet_first_and_fifth, distance_bet_fifth_and_sixth, distance_bet_fourth_and_sixth, distance_bet_third_and_sixth, distance_bet_second_and_sixth, distance_bet_first_and_sixth, distance_bet_sixth_and_seventh, distance_bet_fifth_and_seventh, distance_bet_fourth_and_seventh, distance_bet_third_and_seventh, distance_bet_second_and_seventh, distance_bet_first_and_seventh, distance_bet_seventh_and_eighth, distance_bet_sixth_and_eighth, distance_bet_fifth_and_eighth, distance_bet_fourth_and_eighth, distance_bet_third_and_eighth, distance_bet_second_and_eighth, distance_bet_first_and_eighth

def save_route_img(route_img, route_img_path):
    # Save the image
    cv2.imwrite(route_img_path, route_img)
    return route_img, route_img_path

def resize_route_img(route_img, width, height, resized_route_img_path):
    # resizing the wall image
    route_img_resized = cv2.resize(route_img, (width, height))
    cv2.imwrite(resized_route_img_path, route_img_resized)
    return route_img_resized, resized_route_img_path

def display_route_img_window(route_img_to_display):
    cv2.imshow("Generated Wall Climbing Route", route_img_to_display)

def close_img_window():
    k = cv2.waitKey(0)
    if k == ord('q'):
        cv2.destroyAllWindows()

def generate(user_name, width_input, height_input, climber_height_input, climber_exp):
    width_input = int(width_input)
    height_input = int(height_input)
    climber_height_input = int(climber_height_input)

    width_input, scale_factor = wall_width(width_input) 
    height_input, scale_factor = wall_height(height_input)
    climber_height_input = climber_height(climber_height_input)
    wall_img, scale_factor = create_wall_img(width_input, height_input)
    print(scale_factor)

    holds_list = hold_img(scale_factor)
    foothold, foothold_width, foothold_height = foothold_img(scale_factor)
    custom_holds_list, x_range, y_range_s, y_range_e = custom_holds_list_gen(climber_exp, climber_height_input, holds_list, scale_factor)
    print(f"{x_range}, {y_range_s}, {y_range_e}")

    hold_position_coords_str = ""
    foothold_position_coords_str = ""

    wall_img, first_hold_details, first_hold_coord_list = first_hold(wall_img, width_input, height_input, climber_height_input, custom_holds_list, scale_factor) 
    hold_position_coords_str = hold_position_coords_str + first_hold_details

    wall_img, first_foothold_1_details, first_foothold_2_details = first_two_footholds(first_hold_coord_list, height_input, foothold_width, foothold_height, wall_img, foothold)
    foothold_position_coords_str = foothold_position_coords_str + first_foothold_1_details + "\n" + first_foothold_2_details

    wall_img, second_hold_details, second_hold_coord_list = second_hold(wall_img, height_input, custom_holds_list, first_hold_coord_list, x_range, y_range_s, y_range_e)
    hold_position_coords_str = hold_position_coords_str + "\n" + second_hold_details

    wall_img, third_hold_details, third_hold_coord_list = third_hold(wall_img, height_input, custom_holds_list, second_hold_coord_list, x_range, y_range_s, y_range_e)
    hold_position_coords_str = hold_position_coords_str + "\n" + third_hold_details

    wall_img, second_foothold_1_details, second_foothold_2_details = second_foothold(third_hold_coord_list, height_input, foothold_width, foothold_height, wall_img, foothold)
    foothold_position_coords_str = foothold_position_coords_str + "\n" + second_foothold_1_details + "\n" + second_foothold_2_details

    wall_img, fourth_hold_details, fourth_hold_coord_list = fourth_hold(wall_img, height_input, custom_holds_list, third_hold_coord_list, x_range, y_range_s, y_range_e)
    hold_position_coords_str = hold_position_coords_str + "\n" + fourth_hold_details

    wall_img, fifth_hold_details, fifth_hold_coord_list = fifth_hold(wall_img, height_input, custom_holds_list, fourth_hold_coord_list, x_range, y_range_s, y_range_e)
    hold_position_coords_str = hold_position_coords_str + "\n" + fifth_hold_details

    wall_img, third_foothold_details = third_foothold(fifth_hold_coord_list, first_hold_coord_list, height_input, foothold_width, foothold_height, wall_img, foothold)
    foothold_position_coords_str = foothold_position_coords_str + "\n" + third_foothold_details

    wall_img, sixth_hold_details, sixth_hold_coord_list = sixth_hold(wall_img, height_input, holds_list, fifth_hold_coord_list, x_range, y_range_s, y_range_e)
    hold_position_coords_str = hold_position_coords_str + "\n" + sixth_hold_details

    wall_img, seventh_hold_details, seventh_hold_coord_list = seventh_hold(wall_img, height_input, holds_list, sixth_hold_coord_list, x_range, y_range_s, y_range_e)
    hold_position_coords_str = hold_position_coords_str + "\n" + seventh_hold_details

    wall_img, eighth_hold_details, eighth_hold_coord_list = eighth_hold(wall_img, height_input, holds_list, seventh_hold_coord_list, x_range, y_range_s, y_range_e)
    hold_position_coords_str = hold_position_coords_str + "\n" + eighth_hold_details + "\n"

    wall_img, fourth1_foothold_details, fourth2_foothold_details = fourth_foothold(third_hold_coord_list, fourth_hold_coord_list, eighth_hold_coord_list, height_input, foothold_width, foothold_height, wall_img, foothold)
    foothold_position_coords_str = foothold_position_coords_str + "\n" + fourth1_foothold_details + "\n" + fourth2_foothold_details

    dist_bet_first_and_third, dist_bet_second_and_third, dist_bet_third_and_fourth, dist_bet_second_and_fourth, dist_bet_first_and_fourth, distance_bet_fourth_and_fifth, distance_bet_third_and_fifth, distance_bet_second_and_fifth, distance_bet_first_and_fifth, distance_bet_fifth_and_sixth, distance_bet_fourth_and_sixth, distance_bet_third_and_sixth, distance_bet_second_and_sixth, distance_bet_first_and_sixth, distance_bet_sixth_and_seventh, distance_bet_fifth_and_seventh, distance_bet_fourth_and_seventh, distance_bet_third_and_seventh, distance_bet_second_and_seventh, distance_bet_first_and_seventh, distance_bet_seventh_and_eighth, distance_bet_sixth_and_eighth, distance_bet_fifth_and_eighth, distance_bet_fourth_and_eighth, distance_bet_third_and_eighth, distance_bet_second_and_eighth, distance_bet_first_and_eighth = dist_bet_holds(first_hold_coord_list, second_hold_coord_list, third_hold_coord_list, fourth_hold_coord_list, fifth_hold_coord_list, sixth_hold_coord_list, seventh_hold_coord_list, eighth_hold_coord_list)

    dist_bet_holds_str = dist_bet_first_and_third + "\n" + dist_bet_second_and_third + "\n" + dist_bet_third_and_fourth + "\n" + dist_bet_second_and_fourth + "\n" + dist_bet_first_and_fourth + "\n" + distance_bet_fourth_and_fifth + "\n" + distance_bet_third_and_fifth + "\n" + distance_bet_second_and_fifth + "\n" + distance_bet_first_and_fifth + "\n" + distance_bet_fifth_and_sixth + "\n" + distance_bet_fourth_and_sixth + "\n" + distance_bet_third_and_sixth + "\n" + distance_bet_second_and_sixth + "\n" + distance_bet_first_and_sixth + "\n" + distance_bet_sixth_and_seventh + "\n" + distance_bet_fifth_and_seventh + "\n" + distance_bet_fourth_and_seventh + "\n" + distance_bet_third_and_seventh + "\n" + distance_bet_second_and_seventh + "\n" + distance_bet_first_and_seventh + "\n" + distance_bet_seventh_and_eighth + "\n" + distance_bet_sixth_and_eighth + "\n" + distance_bet_fifth_and_eighth + "\n" + distance_bet_fourth_and_eighth + "\n" + distance_bet_third_and_eighth + "\n" + distance_bet_second_and_eighth + "\n" + distance_bet_first_and_eighth

    cv2.imshow("Generated Route Image", wall_img)
    k = cv2.waitKey(0)
    if k == ord('q'):
        cv2.destroyAllWindows()

    return wall_img, hold_position_coords_str, foothold_position_coords_str, dist_bet_holds_str


def main():
    pass

if __name__ == "__main__":
    main()
  



















