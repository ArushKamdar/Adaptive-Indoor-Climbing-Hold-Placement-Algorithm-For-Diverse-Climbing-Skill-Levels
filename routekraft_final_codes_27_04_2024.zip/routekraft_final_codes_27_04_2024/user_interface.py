from routekraft_module import *
import gradio as gr

# Gradio Interface

def main():
  
    io = gr.Interface(
        fn=generate,
        inputs=[
            gr.Textbox(label="Enter your name", default=""),  
            gr.Number(label="Enter the width of the wall in cms (Enter a value greater than 400 cms)", default = 400),
            gr.Number(label="Enter the height of the wall in cms (Enter a value greater than 400 cms)", default = 400),
            gr.Number(label="Enter the height of the climber in cms (greater than 60 cms and less than 305 cms for your height)", default = 400),
            gr.Radio(label="Select Experience Level:", choices=["Beginner", "Intermediate", "Expert"])   
        ],
        outputs=[
            gr.Image(label="Generated Route Image", width=800, height=500),
            gr.Textbox(label="Generated Route Hold Position Coordinates", show_copy_button = True),
            gr.Textbox(label="Generated Route Foothold Position Coordinates", show_copy_button = True),
            gr.Textbox(label="Distance Between Different Holds", show_copy_button = True)
            ], 
        allow_flagging="manual",
        flagging_options=["Save"],
        title="Adaptive Indoor Climbing Hold Placement Algorithm For Diverse Climbing Skill Levels",
        description="Bouldering, a ropeless form of rock climbing on artificial walls, prioritizes strength, technique, and problem-solving. However, route setting can be costly and time-consuming, with professional setters charging $15-30 per hour. Finding skilled setters can also be challenging. To address these issues, The RouteKraft algorithm was developed for generating customized routes quickly and cost-effectively, eliminating labor and training expenses.",
        theme=gr.themes.Soft()
        # Gradio Themes Guide : https://www.gradio.app/guides/theming-guide
    )
    io.launch(share=True)

if __name__ == "__main__":
    main()